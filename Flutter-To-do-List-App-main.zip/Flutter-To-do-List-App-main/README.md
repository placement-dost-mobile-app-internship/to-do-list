# todo_app
![Main Screen](https://user-images.githubusercontent.com/91030539/222937275-7d2332a1-5034-4ea8-945a-cef9f0f499f2.png)

